# Moonlight Launcher — no-add-on Android project

This project is an Android launcher UI and floating overlay for Minecraft Bedrock. It contains **no `.mcaddon` files and no behavior packs**.

## What currently works
- Launches the installed Minecraft Bedrock app (package `com.mojang.minecraftpe`) when available.
- Requests Android's draw-over-other-apps permission and displays a draggable floating Moonlight button.
- Opens/closes the floating menu and lets you browse Combat, Movement, Render, ESP, Utility, Inventory, and other module categories.
- Saves module toggle preferences locally on the device.
- Provides launcher theme/accent and appearance settings.
- Reset module states clears the locally saved module preferences.

## Important: gameplay features are not implemented
The Combat/Movement/ESP/etc. entries are currently **saved UI preferences, not working Minecraft mods**. This Android overlay cannot by itself change Bedrock's internal player state, attack targeting, reach, movement physics, world rendering, or inventory. This project does not implement KillAura, Fly, AimAssist, Reach, ESP, AutoTotem, or other gameplay cheats, and it does not claim that they work.

The requested no-add-on constraint is respected. To implement genuine game-side features, a compatible integration with the specific Bedrock build is needed (for example, an authorized native integration or a documented proxy/server-side protocol where applicable). A proxy alone cannot guarantee arbitrary client-side effects such as Fly or ESP. Test any future native integration separately and back up worlds before experimenting.

## Build
Open this folder in Android Studio, or use the included GitHub Actions workflow to build the APK. No Gradle wrapper is bundled in this archive; the workflow installs/configures the Android build environment.


## Moonlight demo wallet
- Settings → Infinite Minecoins opens a local demo wallet showing a fixed display balance of 9,999,999.
- The balance is a constant demo display and does not increase or decrease.
- “Simulate demo purchase” records a local demo-owned flag in Android SharedPreferences and remains marked after reopening the overlay.
- This is not real Minecoins, does not modify a Microsoft account or Minecraft Marketplace balance, and does not unlock or purchase paid content.
