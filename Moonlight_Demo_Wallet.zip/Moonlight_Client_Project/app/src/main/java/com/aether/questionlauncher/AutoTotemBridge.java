package com.aether.questionlauncher;

/**
 * Integration contract for a future, version-compatible Minecraft Bedrock native mod.
 *
 * The Android overlay cannot inspect the player inventory or equip items by itself.
 * A trusted game-side integration must implement these operations inside Minecraft and
 * call them from the game's supported update/tick context. This interface intentionally
 * contains no fake inventory logic and is not wired to the overlay yet.
 */
public interface AutoTotemBridge {
    /** True when the game-side integration is attached to a supported game session. */
    boolean isGameSessionReady();

    /** Enable or disable automatic offhand totem handling in the game-side module. */
    void setAutoTotemEnabled(boolean enabled);

    /** Optional concise status such as "Totem equipped", "No totem", or "Not in game". */
    String getAutoTotemStatus();
}
