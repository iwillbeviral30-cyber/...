package com.aether.questionlauncher;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class OverlayService extends Service {
    private final int BG=Color.rgb(5,10,25), PANEL=Color.rgb(8,16,37), ROW=Color.rgb(12,24,49), PURPLE=Color.rgb(111,55,255), MUTED=Color.rgb(143,169,221), WHITE=Color.rgb(239,243,255);
    private WindowManager wm; private View bubble,panel; private WindowManager.LayoutParams bubbleParams,panelParams;
    private LinearLayout featureList,categoryList,detailsPanel; private TextView statusText,heading,detailTitle,detailDescription;
    private String selected="Combat"; private String selectedModule=null; private SharedPreferences prefs;
    // Empty starter navigation: modules will be added one at a time as real implementations are built.
    private final String[] categories={"Home","Combat","Movement","Render","Misc","Settings"};

    @Override public void onCreate() {
        super.onCreate(); prefs=getSharedPreferences("moonlight_states",MODE_PRIVATE);
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel ch=new NotificationChannel("moonlight","Moonlight overlay",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        Notification.Builder nb = Build.VERSION.SDK_INT>=26
            ? new Notification.Builder(this,"moonlight") : new Notification.Builder(this);
        Notification n=nb.setContentTitle("Moonlight overlay active")
            .setContentText("Tap the floating Moonlight icon to open or close the menu.")
            .setSmallIcon(android.R.drawable.ic_menu_help).setOngoing(true).build();
        startForeground(71,n); if(Settings.canDrawOverlays(this)) addBubble();
    }
    private int type(){return Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable shape(int color,int stroke,int radius){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(2),stroke); return d;
    }
    private void addBubble(){
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        ImageView b=new ImageView(this); b.setImageResource(com.aether.questionlauncher.R.drawable.aether_question_icon); b.setScaleType(ImageView.ScaleType.CENTER_CROP);
        b.setBackground(shape(Color.rgb(15,16,19),0,100));
        bubbleParams=new WindowManager.LayoutParams(dp(44),dp(44),type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        bubbleParams.gravity=Gravity.TOP|Gravity.START; bubbleParams.x=dp(12); bubbleParams.y=dp(80); bubble=b;
        try{wm.addView(bubble,bubbleParams);}catch(Exception e){stopSelf();return;}
        b.setOnTouchListener(new View.OnTouchListener(){
            float x,y;int sx,sy;
            public boolean onTouch(View v,MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();sx=bubbleParams.x;sy=bubbleParams.y;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){bubbleParams.x=sx+(int)(e.getRawX()-x);bubbleParams.y=sy+(int)(e.getRawY()-y);
                    try{wm.updateViewLayout(bubble,bubbleParams);}catch(Exception ignored){} return true;}
                if(e.getAction()==MotionEvent.ACTION_UP){if(Math.abs(e.getRawX()-x)<10&&Math.abs(e.getRawY()-y)<10)togglePanel();return true;}
                return true;
            }
        });
    }
    private TextView label(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private void togglePanel(){if(panel!=null){removePanel();return;}buildPanel();}
    private void buildPanel(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(8),dp(7),dp(8),dp(7));
        root.setBackground(shape(PANEL,Color.rgb(48,70,126),14));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand=label("☾  Moonlight",17,WHITE,true);top.addView(brand,new LinearLayout.LayoutParams(0,dp(34),1));
        TextView build=label("BEDROCK CLIENT  •  PREVIEW",9,MUTED,true);top.addView(build,new LinearLayout.LayoutParams(-2,dp(34)));
        TextView close=label("×",26,WHITE,true);close.setGravity(Gravity.CENTER);close.setBackground(shape(ROW,0,8));
        top.addView(close,new LinearLayout.LayoutParams(dp(34),dp(32)));close.setOnClickListener(v->removePanel());root.addView(top);
        TextView sub=label("CLIENT MENU     /     MODULE WORKSPACE",9,MUTED,true);root.addView(sub,new LinearLayout.LayoutParams(-1,dp(21)));
        View divider=new View(this);divider.setBackgroundColor(Color.rgb(42,58,100));root.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,0,1);bp.topMargin=dp(6);bp.bottomMargin=dp(4);root.addView(body,bp);
        ScrollView cs=new ScrollView(this);categoryList=new LinearLayout(this);categoryList.setPadding(dp(2),dp(2),dp(2),dp(2));categoryList.setOrientation(LinearLayout.VERTICAL);
        cs.addView(categoryList);body.addView(cs,new LinearLayout.LayoutParams(dp(105),-1));
        LinearLayout center=new LinearLayout(this);center.setOrientation(LinearLayout.VERTICAL);center.setPadding(dp(7),0,dp(5),0);
        body.addView(center,new LinearLayout.LayoutParams(0,-1,1.05f));
        heading=label(selected,15,WHITE,true);center.addView(heading,new LinearLayout.LayoutParams(-1,dp(34)));
        TextView hint=label("MODULES",9,MUTED,true);center.addView(hint,new LinearLayout.LayoutParams(-1,dp(20)));
        ScrollView fs=new ScrollView(this);featureList=new LinearLayout(this);featureList.setOrientation(LinearLayout.VERTICAL);fs.addView(featureList);
        center.addView(fs,new LinearLayout.LayoutParams(-1,0,1));
        detailsPanel=new LinearLayout(this);detailsPanel.setOrientation(LinearLayout.VERTICAL);detailsPanel.setPadding(dp(12),dp(12),dp(12),dp(12));detailsPanel.setBackground(shape(Color.rgb(8,19,43),Color.rgb(76,56,170),12));
        LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(0,-1,1);dlp.leftMargin=dp(3);detailsPanel.setVisibility(View.GONE);body.addView(detailsPanel,dlp);
        TextView foot=label("STARTER LAYOUT  •  NO GAMEPLAY MODULES ADDED",8,MUTED,false);root.addView(foot,new LinearLayout.LayoutParams(-1,dp(18)));
        panel=root;int sw=getResources().getDisplayMetrics().widthPixels,sh=getResources().getDisplayMetrics().heightPixels;
        int w=Math.min((int)(sw*.97f),dp(980)),h=Math.min((int)(sh*.88f),dp(650));
        panelParams=new WindowManager.LayoutParams(w,h,type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        panelParams.gravity=Gravity.CENTER;
        try{wm.addView(panel,panelParams);renderCategories();renderFeatures();renderDetails();}
        catch(Exception e){panel=null;Toast.makeText(this,"Could not show menu: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private String icon(String c){switch(c){case "Home":return "⌂";case "Combat":return "⚔";case "Movement":return "➤";case "Render":return "◉";case "Misc":return "✳";default:return "☷";}}
    private void renderCategories(){
        categoryList.removeAllViews();
        for(String c:categories){
            TextView t=label(icon(c)+"  "+c,10,c.equals(selected)?WHITE:Color.rgb(183,199,236),c.equals(selected));
            t.setPadding(dp(7),0,dp(2),0);t.setBackground(shape(c.equals(selected)?Color.rgb(54,39,143):BG,c.equals(selected)?PURPLE:0,8));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(39));p.bottomMargin=dp(5);categoryList.addView(t,p);
            t.setOnClickListener(v->{selected=c;selectedModule=null;heading.setText(c);detailsPanel.setVisibility(View.GONE);renderCategories();renderFeatures();});
        }
        TextView brandFoot=label("☾  MOONLIGHT\nv0.1  •  BUILDING",9,MUTED,true);brandFoot.setPadding(dp(7),dp(8),0,0);categoryList.addView(brandFoot,new LinearLayout.LayoutParams(-1,dp(54)));
    }
    private void renderFeatures(){
        featureList.removeAllViews();
        if("Settings".equals(selected)){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(10),dp(9),dp(8),dp(9));
            row.setBackground(shape(ROW,Color.rgb(31,49,91),10));
            TextView title=label("◈  Infinite Minecoins",12,WHITE,true);
            row.addView(title,new LinearLayout.LayoutParams(-1,dp(27)));
            TextView desc=label("Demo wallet • 9,999,999 MC",9,MUTED,false);
            row.addView(desc,new LinearLayout.LayoutParams(-1,dp(22)));
            featureList.addView(row,new LinearLayout.LayoutParams(-1,-2));
            row.setOnClickListener(v->showWalletDetails());
            return;
        }
        LinearLayout empty=new LinearLayout(this);empty.setOrientation(LinearLayout.VERTICAL);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(8),dp(14),dp(8),dp(14));empty.setBackground(shape(ROW,Color.rgb(31,49,91),10));
        TextView symbol=label("＋",28,PURPLE,true);symbol.setGravity(Gravity.CENTER);empty.addView(symbol,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView title=label("No modules added",13,WHITE,true);title.setGravity(Gravity.CENTER);empty.addView(title,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView msg=label("No features added yet.\nWe'll add and test modules one by one.",10,MUTED,false);msg.setGravity(Gravity.CENTER);empty.addView(msg,new LinearLayout.LayoutParams(-1,dp(48)));
        featureList.addView(empty,new LinearLayout.LayoutParams(-1,-2));
    }
    // Local demo wallet only. It never connects to or modifies Microsoft/Minecraft accounts.
    private void showWalletDetails(){
        selectedModule="Infinite Minecoins";
        detailsPanel.setVisibility(View.VISIBLE);
        detailsPanel.removeAllViews();
        TextView eyebrow=label("MOONLIGHT DEMO WALLET",9,PURPLE,true);
        detailsPanel.addView(eyebrow,new LinearLayout.LayoutParams(-1,dp(22)));
        TextView title=label("Infinite Minecoins",14,WHITE,true);title.setGravity(Gravity.CENTER);
        detailsPanel.addView(title,new LinearLayout.LayoutParams(-1,dp(30)));
        TextView balanceCaption=label("DEMO BALANCE",9,MUTED,true);balanceCaption.setGravity(Gravity.CENTER);
        detailsPanel.addView(balanceCaption,new LinearLayout.LayoutParams(-1,dp(22)));
        TextView balance=label("◈  9,999,999",25,WHITE,true);balance.setGravity(Gravity.CENTER);
        detailsPanel.addView(balance,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView fixed=label("FIXED DEMO BALANCE • DOES NOT CHANGE",8,PURPLE,true);fixed.setGravity(Gravity.CENTER);
        detailsPanel.addView(fixed,new LinearLayout.LayoutParams(-1,dp(24)));
        View line=new View(this);line.setBackgroundColor(Color.rgb(42,58,100));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(1));lp.topMargin=dp(8);lp.bottomMargin=dp(10);detailsPanel.addView(line,lp);
        TextView demoTitle=label("Demo Marketplace",12,WHITE,true);
        detailsPanel.addView(demoTitle,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView demoDesc=label("Try a simulated purchase. This only records a local demo state; it does not buy or unlock real Marketplace content.",9,MUTED,false);
        demoDesc.setPadding(0,dp(3),0,dp(8));detailsPanel.addView(demoDesc,new LinearLayout.LayoutParams(-1,-2));
        boolean owned=prefs.getBoolean("demo_wallet_item_owned",false);
        TextView purchase=label(owned?"✓  Demo item purchased":"＋  Simulate demo purchase",11,WHITE,true);
        purchase.setGravity(Gravity.CENTER);purchase.setPadding(dp(6),0,dp(6),0);
        purchase.setBackground(shape(owned?Color.rgb(25,75,68):Color.rgb(54,39,143),owned?Color.rgb(45,160,132):PURPLE,9));
        detailsPanel.addView(purchase,new LinearLayout.LayoutParams(-1,dp(42)));
        purchase.setOnClickListener(v->{
            if(!prefs.getBoolean("demo_wallet_item_owned",false)){
                prefs.edit().putBoolean("demo_wallet_item_owned",true).apply();
                Toast.makeText(this,"Demo purchase recorded locally. No real content was purchased.",Toast.LENGTH_LONG).show();
                showWalletDetails();
            } else {
                Toast.makeText(this,"Demo item already marked as purchased.",Toast.LENGTH_SHORT).show();
            }
        });
        TextView disclaimer=label("DEMO ONLY • Your real Minecraft balance and Marketplace are unchanged.",8,MUTED,false);
        disclaimer.setPadding(0,dp(10),0,0);detailsPanel.addView(disclaimer,new LinearLayout.LayoutParams(-1,-2));
    }

    // Called by a future module row when a module is selected. The right-hand panel
    // stays hidden until a real module is added and selected.
    private void showModuleDetails(String moduleName, String description){
        selectedModule=moduleName;
        detailsPanel.setVisibility(View.VISIBLE);
        detailsPanel.removeAllViews();
        TextView eyebrow=label("MODULE DETAILS",9,PURPLE,true);
        detailsPanel.addView(eyebrow,new LinearLayout.LayoutParams(-1,dp(22)));
        TextView glyph=label("◇",34,PURPLE,true);glyph.setGravity(Gravity.CENTER);
        detailsPanel.addView(glyph,new LinearLayout.LayoutParams(-1,dp(55)));
        TextView title=label(moduleName,14,WHITE,true);title.setGravity(Gravity.CENTER);
        detailsPanel.addView(title,new LinearLayout.LayoutParams(-1,dp(32)));
        TextView desc=label(description,10,MUTED,false);desc.setGravity(Gravity.CENTER);desc.setPadding(dp(3),dp(4),dp(3),dp(4));
        detailsPanel.addView(desc,new LinearLayout.LayoutParams(-1,-2));
        View line=new View(this);line.setBackgroundColor(Color.rgb(42,58,100));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(1));lp.topMargin=dp(12);lp.bottomMargin=dp(12);detailsPanel.addView(line,lp);
        String noteText = "Infinite Minecoins".equals(moduleName)
            ? "UI PREVIEW ONLY • This does not change your actual Minecraft Marketplace balance."
            : "Settings for this module will be added when we build it.";
        TextView note=label(noteText,9,MUTED,false);note.setPadding(0,dp(5),0,0);
        detailsPanel.addView(note,new LinearLayout.LayoutParams(-1,-2));
    }
    private void removePanel(){if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panel=null;}}
    @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
    @Override public void onDestroy(){removePanel();if(bubble!=null&&wm!=null){try{wm.removeView(bubble);}catch(Exception ignored){}bubble=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
